ساخت APK کدیار با مدل آفلاین (ساخت ابری با GitHub)

۱) در github.com حساب بساز و یک Repository جدید بساز (Public یا Private).
۲) داخل Repository: Add file ← Upload files ← فایل kodyar-project.zip را (بدون باز کردن) آپلود کن ← Commit.
۳) Add file ← Create new file. اسمش را دقیقاً این بنویس:  .github/workflows/build.yml
   متن فایل build.yml را داخلش بچسبان ← Commit.
۴) تب Actions ← «Build kodyar APK» ← Run workflow. حدود ۱۵ تا ۳۰ دقیقه صبر کن.
۵) وقتی سبز شد، وارد آن اجرا شو و پایین صفحه، در بخش Artifacts، kodyar-apk را دانلود کن (zip است؛ باز کن و app-debug.apk را نصب کن).
۶) در برنامه: بخش ۳ ← «بنویس برایم (آفلاین)» ← دانلود مدل (یا انتخاب فایل .gguf) ← بارگذاری مدل ← توضیح فارسی بنویس.
اگر ساخت قرمز شد، متن خطای آخر لاگ را برای Claude بفرست.
