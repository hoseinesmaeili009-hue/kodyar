set -e
mkdir -p www && cp index.html www/index.html
npm install
npx cap add android
git clone --depth 1 --branch b5000 https://github.com/ggml-org/llama.cpp android/app/src/main/cpp/llama.cpp
rm -rf android/app/src/main/cpp/llama.cpp/.git
cp overlay/cpp/* android/app/src/main/cpp/
mkdir -p android/app/src/main/java/com/kodyar/app
cp overlay/java/* android/app/src/main/java/com/kodyar/app/
python3 patch_gradle.py
npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleDebug --no-daemon
