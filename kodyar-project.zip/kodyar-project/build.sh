set -e
mkdir -p www && cp index.html www/index.html
npm install
npx cap add android
URL=https://github.com/ggml-org/llama.cpp
TAG=$(git ls-remote --tags $URL "refs/tags/b50[0-4][0-9]" | sed 's|.*refs/tags/||' | grep -v '\^' | sort -V | head -1)
echo "llama.cpp tag: $TAG"
test -n "$TAG"
git clone --depth 1 --branch $TAG $URL android/app/src/main/cpp/llama.cpp
rm -rf android/app/src/main/cpp/llama.cpp/.git
cp overlay/cpp/* android/app/src/main/cpp/
mkdir -p android/app/src/main/java/com/kodyar/app
cp overlay/java/* android/app/src/main/java/com/kodyar/app/
python3 patch_gradle.py
npx cap sync android
cd android
chmod +x gradlew
set +e
./gradlew assembleDebug --no-daemon --console=plain > ../build.log 2>&1
CODE=$?
set -e
if [ $CODE -ne 0 ]; then
  echo "=========== KODYAR ERRORS ==========="
  grep -E "error:|fatal error|undefined reference|What went wrong|CMake Error|ld: error" ../build.log | cut -c1-260 | head -40
  echo "=========== END ERRORS ==========="
  exit 1
fi
