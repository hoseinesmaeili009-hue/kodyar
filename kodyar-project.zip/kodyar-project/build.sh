set -e
mkdir -p www && cp index.html www/index.html
npm install
npx cap add android
URL=https://github.com/ggml-org/llama.cpp
TAG=$(git ls-remote --tags $URL "refs/tags/b50[0-4][0-9]" | sed 's|.*refs/tags/||' | grep -v '\^' | sort -V | head -1)
echo "llama.cpp tag: $TAG"
test -n "$TAG"
git clone --depth 1 --branch $TAG $URL android/app/src/main/cpp/llama.cpp
rm -rf android/app/src/main/cpp/llama.cpp/.git
cp overlay/cpp/* android/app/src/main/cpp/
mkdir -p android/app/src/main/java/com/kodyar/app
cp overlay/java/* android/app/src/main/java/com/kodyar/app/
python3 patch_gradle.py
npx cap sync android
cd android
chmod +x gradlew
./gradlew assembleDebug --no-daemon
