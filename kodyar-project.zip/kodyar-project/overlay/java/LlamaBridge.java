package com.kodyar.app;

public class LlamaBridge {
    static { System.loadLibrary("kodyar_llama"); }
    public interface TokenCb { void onToken(byte[] utf8); }
    public static native boolean nativeLoad(String path);
    public static native void nativeGenerate(byte[] system, byte[] user, int maxTokens, TokenCb cb);
    public static native void nativeStop();
    public static native void nativeFree();
}
