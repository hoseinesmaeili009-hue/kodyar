package com.kodyar.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@CapacitorPlugin(name = "Llama")
public class LlamaPlugin extends Plugin {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean loaded = false;
    private volatile boolean cancelDl = false;

    private SharedPreferences prefs() { return getContext().getSharedPreferences("kodyar_llama", Context.MODE_PRIVATE); }
    private File dir() { return getContext().getExternalFilesDir(null); }

    private String modelPath() {
        String p = prefs().getString("model_path", null);
        return (p != null && new File(p).exists()) ? p : null;
    }

    private void progress(long done, long total) {
        JSObject o = new JSObject();
        o.put("done", done);
        o.put("total", total);
        notifyListeners("download", o);
    }

    @PluginMethod
    public void status(PluginCall call) {
        JSObject o = new JSObject();
        String p = modelPath();
        o.put("loaded", loaded);
        o.put("hasModel", p != null);
        o.put("sizeMB", p != null ? new File(p).length() / 1048576 : 0);
        call.resolve(o);
    }

    @PluginMethod
    public void download(PluginCall call) {
        final String url = call.getString("url", "");
        if (url.isEmpty()) { call.reject("آدرس خالی است"); return; }
        cancelDl = false;
        new Thread(() -> {
            try {
                File part = new File(dir(), "model.gguf.part"), fin = new File(dir(), "model.gguf");
                long have = part.exists() ? part.length() : 0;
                HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
                c.setConnectTimeout(20000);
                c.setReadTimeout(30000);
                if (have > 0) c.setRequestProperty("Range", "bytes=" + have + "-");
                c.connect();
                int code = c.getResponseCode();
                if (code != 200 && code != 206) { call.reject("خطای سرور " + code); return; }
                boolean resume = code == 206;
                if (!resume) have = 0;
                long total = c.getContentLengthLong() + (resume ? have : 0);
                long done = have, last = 0;
                try (InputStream in = c.getInputStream(); FileOutputStream out = new FileOutputStream(part, resume)) {
                    byte[] buf = new byte[1 << 16];
                    int r;
                    while ((r = in.read(buf)) != -1) {
                        if (cancelDl) { call.reject("لغو شد"); return; }
                        out.write(buf, 0, r);
                        done += r;
                        long now = System.currentTimeMillis();
                        if (now - last > 500) { last = now; progress(done, total); }
                    }
                }
                if (total > 0 && done < total) { call.reject("دانلود ناقص ماند؛ دوباره بزن تا ادامه پیدا کند"); return; }
                if (fin.exists()) fin.delete();
                if (!part.renameTo(fin)) { call.reject("ذخیرهٔ فایل نشد"); return; }
                prefs().edit().putString("model_path", fin.getAbsolutePath()).apply();
                progress(done, total);
                call.resolve();
            } catch (Exception e) {
                call.reject("خطا: " + e);
            }
        }).start();
    }

    @PluginMethod
    public void cancelDownload(PluginCall call) { cancelDl = true; call.resolve(); }

    @PluginMethod
    public void pick(PluginCall call) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(call, i, "pickResult");
    }

    @ActivityCallback
    private void pickResult(PluginCall call, ActivityResult result) {
        if (call == null) return;
        if (result.getResultCode() != Activity.RESULT_OK || result.getData() == null || result.getData().getData() == null) {
            call.reject("انتخابی انجام نشد");
            return;
        }
        final Uri uri = result.getData().getData();
        new Thread(() -> {
            try {
                File part = new File(dir(), "model.gguf.part"), fin = new File(dir(), "model.gguf");
                long total = 0;
                try (android.database.Cursor cu = getContext().getContentResolver().query(uri, null, null, null, null)) {
                    if (cu != null && cu.moveToFirst()) {
                        int ix = cu.getColumnIndex(android.provider.OpenableColumns.SIZE);
                        if (ix >= 0) total = cu.getLong(ix);
                    }
                }
                long done = 0, last = 0;
                try (InputStream in = getContext().getContentResolver().openInputStream(uri); FileOutputStream out = new FileOutputStream(part, false)) {
                    byte[] buf = new byte[1 << 16];
                    int r;
                    while ((r = in.read(buf)) != -1) {
                        out.write(buf, 0, r);
                        done += r;
                        long now = System.currentTimeMillis();
                        if (now - last > 500) { last = now; progress(done, total); }
                    }
                }
                if (fin.exists()) fin.delete();
                if (!part.renameTo(fin)) { call.reject("ذخیرهٔ فایل نشد"); return; }
                prefs().edit().putString("model_path", fin.getAbsolutePath()).apply();
                progress(done, total);
                call.resolve();
            } catch (Exception e) {
                call.reject("خطا (شاید جای خالی کافی نیست): " + e);
            }
        }).start();
    }

    @PluginMethod
    public void load(PluginCall call) {
        worker.execute(() -> {
            try {
                String p = modelPath();
                if (p == null) { call.reject("مدلی پیدا نشد"); return; }
                loaded = LlamaBridge.nativeLoad(p);
                if (loaded) call.resolve(); else call.reject("مدل باز نشد (فایل خراب یا ناسازگار)");
            } catch (Throwable e) {
                call.reject("خطا: " + e);
            }
        });
    }

    @PluginMethod
    public void generate(PluginCall call) {
        final String prompt = call.getString("prompt", "");
        final String system = call.getString("system", "");
        final int max = call.getInt("maxTokens", 1200);
        if (!loaded) { call.reject("اول مدل را بارگذاری کن"); return; }
        worker.execute(() -> {
            try {
                LlamaBridge.nativeGenerate(system.getBytes(StandardCharsets.UTF_8), prompt.getBytes(StandardCharsets.UTF_8), max, bytes -> {
                    JSObject o = new JSObject();
                    o.put("t", new String(bytes, StandardCharsets.UTF_8));
                    notifyListeners("token", o);
                });
                call.resolve();
            } catch (Throwable e) {
                call.reject("خطا: " + e);
            }
        });
    }

    @PluginMethod
    public void stop(PluginCall call) { LlamaBridge.nativeStop(); call.resolve(); }

    @PluginMethod
    public void deleteModel(PluginCall call) {
        worker.execute(() -> {
            try {
                if (loaded) { LlamaBridge.nativeFree(); loaded = false; }
                String p = prefs().getString("model_path", null);
                if (p != null) new File(p).delete();
                prefs().edit().remove("model_path").apply();
                call.resolve();
            } catch (Throwable e) {
                call.reject("خطا: " + e);
            }
        });
    }
}
