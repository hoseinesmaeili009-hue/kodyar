#include <jni.h>
#include <android/log.h>
#include <unistd.h>
#include <string>
#include <vector>
#include <atomic>
#include <mutex>
#include <algorithm>
#include "llama.h"

#define TAG "kodyar"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

static llama_model* g_model = nullptr;
static std::atomic<bool> g_stop(false);
static std::mutex g_mu;
static bool g_inited = false;

static std::string bytes_to_string(JNIEnv* env, jbyteArray a) {
    jsize n = env->GetArrayLength(a);
    std::string s(n, '\0');
    if (n > 0) env->GetByteArrayRegion(a, 0, n, reinterpret_cast<jbyte*>(&s[0]));
    return s;
}

// طول بخشی از متن که UTF-8 کامل است (حرف نیمه‌کاره نگه داشته می‌شود)
static size_t complete_prefix(const std::string& s) {
    size_t n = s.size();
    for (size_t back = 1; back <= 3 && back <= n; back++) {
        unsigned char c = (unsigned char)s[n - back];
        if ((c & 0xC0) == 0x80) continue;
        size_t need = c >= 0xF0 ? 4 : c >= 0xE0 ? 3 : c >= 0xC0 ? 2 : 1;
        return need > back ? n - back : n;
    }
    return n;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_kodyar_app_LlamaBridge_nativeLoad(JNIEnv* env, jclass, jstring jpath) {
    std::lock_guard<std::mutex> lk(g_mu);
    if (!g_inited) { llama_backend_init(); g_inited = true; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
    const char* path = env->GetStringUTFChars(jpath, nullptr);
    llama_model_params mp = llama_model_default_params();
    g_model = llama_model_load_from_file(path, mp);
    LOGI("load %s -> %s", path, g_model ? "ok" : "FAILED");
    env->ReleaseStringUTFChars(jpath, path);
    return g_model != nullptr;
}

extern "C" JNIEXPORT void JNICALL
Java_com_kodyar_app_LlamaBridge_nativeStop(JNIEnv*, jclass) { g_stop = true; }

extern "C" JNIEXPORT void JNICALL
Java_com_kodyar_app_LlamaBridge_nativeFree(JNIEnv*, jclass) {
    g_stop = true;
    std::lock_guard<std::mutex> lk(g_mu);
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}

extern "C" JNIEXPORT void JNICALL
Java_com_kodyar_app_LlamaBridge_nativeGenerate(JNIEnv* env, jclass, jbyteArray jsys, jbyteArray juser, jint maxTok, jobject cb) {
    std::lock_guard<std::mutex> lk(g_mu);
    g_stop = false;
    jclass cls = env->GetObjectClass(cb);
    jmethodID mid = env->GetMethodID(cls, "onToken", "([B)V");
    auto emit = [&](const std::string& s) {
        if (s.empty()) return;
        jbyteArray a = env->NewByteArray((jsize)s.size());
        env->SetByteArrayRegion(a, 0, (jsize)s.size(), reinterpret_cast<const jbyte*>(s.data()));
        env->CallVoidMethod(cb, mid, a);
        env->DeleteLocalRef(a);
    };
    if (!g_model) { emit("[خطا: مدل بارگذاری نشده]"); return; }

    std::string sys = bytes_to_string(env, jsys), user = bytes_to_string(env, juser);
    llama_chat_message msgs[2] = { {"system", sys.c_str()}, {"user", user.c_str()} };
    const char* tmpl = llama_model_chat_template(g_model, nullptr);
    if (!tmpl) tmpl = "chatml";
    std::vector<char> buf(sys.size() + user.size() + 2048);
    int n = llama_chat_apply_template(tmpl, msgs, 2, true, buf.data(), (int)buf.size());
    if (n > (int)buf.size()) { buf.resize(n + 16); n = llama_chat_apply_template(tmpl, msgs, 2, true, buf.data(), (int)buf.size()); }
    if (n < 0) { emit("[خطا: قالب گفتگو ساخته نشد]"); return; }
    std::string prompt(buf.data(), n);

    const llama_vocab* vocab = llama_model_get_vocab(g_model);
    std::vector<llama_token> toks(prompt.size() + 16);
    int nt = llama_tokenize(vocab, prompt.c_str(), (int)prompt.size(), toks.data(), (int)toks.size(), false, true);
    if (nt < 0) { toks.resize(-nt); nt = llama_tokenize(vocab, prompt.c_str(), (int)prompt.size(), toks.data(), (int)toks.size(), false, true); }
    if (nt <= 0) { emit("[خطا: متن پردازش نشد]"); return; }
    toks.resize(nt);

    const int n_ctx = 4096, n_batch = 512;
    if (nt + 64 >= n_ctx) { emit("[خطا: توضیح خیلی بلند است]"); return; }
    int budget = std::min((int)maxTok, n_ctx - nt - 8);

    int threads = std::max(2, std::min(6, (int)sysconf(_SC_NPROCESSORS_CONF) / 2));
    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = n_ctx; cp.n_batch = n_batch; cp.n_threads = threads; cp.n_threads_batch = threads;
    llama_context* ctx = llama_init_from_model(g_model, cp);
    if (!ctx) { emit("[خطا: حافظه کافی نیست]"); return; }

    llama_sampler* smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.2f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(1234));

    bool ok = true;
    for (int i = 0; i < nt && ok && !g_stop; i += n_batch) {
        int c = std::min(n_batch, nt - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, c);
        if (llama_decode(ctx, b) != 0) ok = false;
    }
    if (!ok) emit("[خطا در پردازش]");

    std::string pending;
    for (int i = 0; ok && i < budget && !g_stop; i++) {
        llama_token t = llama_sampler_sample(smpl, ctx, -1);
        if (llama_vocab_is_eog(vocab, t)) break;
        char piece[256];
        int len = llama_token_to_piece(vocab, t, piece, sizeof(piece), 0, false);
        if (len > 0) pending.append(piece, len);
        size_t k = complete_prefix(pending);
        if (k > 0) { emit(pending.substr(0, k)); pending.erase(0, k); }
        llama_batch b = llama_batch_get_one(&t, 1);
        if (llama_decode(ctx, b) != 0) break;
    }
    if (!pending.empty()) emit(pending);
    llama_sampler_free(smpl);
    llama_free(ctx);
}
