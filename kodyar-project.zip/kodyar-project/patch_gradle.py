p = 'android/app/build.gradle'
s = open(p, encoding='utf-8').read()
assert 'android {' in s and 'defaultConfig {' in s
s = s.replace('android {', 'android {\n    ndkVersion "26.1.10909125"\n    externalNativeBuild {\n        cmake {\n            path "src/main/cpp/CMakeLists.txt"\n            version "3.22.1"\n        }\n    }\n', 1)
s = s.replace('defaultConfig {', 'defaultConfig {\n        ndk { abiFilters "arm64-v8a" }\n        externalNativeBuild { cmake { arguments "-DANDROID_STL=c++_static" } }\n', 1)
open(p, 'w', encoding='utf-8').write(s)
print('gradle patched')
